#!/usr/bin/env python3
"""
🔧 Stage 1 重構處理器

按照文檔要求重構 Stage 1，專注於核心職責：
1. TLE 數據載入和解析
2. 數據完整性驗證
3. 時間基準建立
4. 衛星數據分組和標準化

嚴格遵循單一職責原則，不侵犯其他階段職責。

作者: Claude
創建: 2025-09-24
標準: 文檔規範 v2.0
"""

from typing import Dict, Any, Optional, List
from datetime import datetime, timezone, timedelta
import logging
import json
from pathlib import Path

# 導入標準接口
from shared.interfaces.processor_interface import ProcessingResult, ProcessingStatus, ProcessingMetrics
from shared.base_processor import BaseStageProcessor

# 導入現有組件
from ..stage1_main_processor import Stage1MainProcessor


class Stage1RefactoredProcessor(BaseStageProcessor):
    """
    📋 Stage 1 重構處理器

    按照文檔 v2.0 規範重構的 Stage 1 處理器，專注於：
    - TLE 數據載入和解析
    - 數據完整性驗證
    - 時間基準建立
    - 標準化接口實現
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化重構後的 Stage 1 處理器

        Args:
            config: 配置參數
        """
        # 調用父類初始化
        super().__init__(
            stage_number=1,
            stage_name="refactored_tle_data_loading",
            config=config
        )

        # 使用現有的核心處理器作為數據處理引擎
        self.core_processor = Stage1MainProcessor(config=config)

        # TLE 格式驗證配置
        self.tle_validation_config = {
            'strict_format_check': True,
            'checksum_verification': True,
            'line_length_check': True,
            'required_fields_check': True
        }

        # 時間基準配置
        self.time_config = {
            'precision_seconds': 1e-6,  # 微秒精度
            'output_format': 'iso_8601',
            'timezone': 'UTC',
            'epoch_aging_limit_days': 30
        }

        self.logger.info("🔧 Stage 1 重構處理器初始化完成")

    def validate_input(self, input_data: Any) -> Dict[str, Any]:
        """
        驗證輸入數據

        Args:
            input_data: 輸入數據

        Returns:
            驗證結果字典
        """
        try:
            errors = []
            warnings = []

            # 基本輸入檢查 - Stage 1 可接受空輸入（從TLE文件載入）
            if input_data is not None:
                if not isinstance(input_data, dict):
                    errors.append("輸入數據必須為字典格式或 None")

                # 檢查是否有不合理的預處理數據
                if isinstance(input_data, dict) and len(input_data) > 0:
                    warnings.append("Stage 1 通常從 TLE 文件載入數據，不需要輸入數據")

            return {
                'valid': len(errors) == 0,
                'errors': errors,
                'warnings': warnings,
                'validation_level': 'STAGE1_INPUT'
            }

        except Exception as e:
            self.logger.error(f"❌ 輸入驗證異常: {e}")
            return {
                'valid': False,
                'errors': [f"輸入驗證異常: {str(e)}"],
                'warnings': []
            }

    def process(self, input_data: Optional[Any] = None) -> ProcessingResult:
        """
        執行 Stage 1 重構處理流程

        Args:
            input_data: 輸入數據（通常為 None，從 TLE 文件載入）

        Returns:
            ProcessingResult: 標準化處理結果
        """
        start_time = datetime.now(timezone.utc)

        try:
            self.logger.info("🔧 開始 Stage 1 重構處理...")

            # 使用核心處理器執行數據載入
            core_result = self.core_processor.process(input_data)

            # 執行重構後的後處理
            refactored_data = self._apply_refactored_post_processing(core_result)

            # 創建標準化 ProcessingResult
            processing_result = ProcessingResult(
                status=ProcessingStatus.SUCCESS,
                data=refactored_data,
                metadata=refactored_data.get('metadata', {}),
                errors=[],
                warnings=[]
            )

            # 計算處理指標
            end_time = datetime.now(timezone.utc)
            duration = (end_time - start_time).total_seconds()

            processing_result.metrics = ProcessingMetrics(
                start_time=start_time,
                end_time=end_time,
                duration_seconds=duration,
                input_records=0,  # Stage 1 從文件載入
                output_records=len(refactored_data.get('satellites', [])),
                processed_records=len(refactored_data.get('satellites', [])),
                success_rate=1.0,
                throughput_per_second=len(refactored_data.get('satellites', [])) / max(duration, 0.001)
            )

            # 更新元數據
            processing_result.metadata.update({
                'interface_compliance': 'BaseStageProcessor_v2.0',
                'refactored_version': True,
                'processing_framework': 'Stage1RefactoredProcessor'
            })

            self.logger.info(f"✅ Stage 1 重構處理完成，耗時: {duration:.3f}秒")
            return processing_result

        except Exception as e:
            self.logger.error(f"❌ Stage 1 重構處理失敗: {e}")
            return ProcessingResult(
                status=ProcessingStatus.FAILED,
                data={},
                metadata={'error': str(e), 'refactored_version': True},
                errors=[str(e)],
                warnings=[]
            )

    def validate_output(self, output_data: Any) -> Dict[str, Any]:
        """
        驗證輸出數據

        Args:
            output_data: 輸出數據

        Returns:
            驗證結果字典
        """
        try:
            errors = []
            warnings = []
            validation_score = 1.0

            # 檢查數據結構
            if not isinstance(output_data, dict):
                errors.append("輸出數據必須為字典格式")
                validation_score -= 0.5
                return {
                    'valid': False,
                    'errors': errors,
                    'warnings': warnings,
                    'validation_score': validation_score
                }

            # 檢查必要字段 - Stage 1 核心輸出
            required_fields = ['stage', 'satellites', 'metadata']
            for field in required_fields:
                if field not in output_data:
                    errors.append(f"缺少必要字段: {field}")
                    validation_score -= 0.2

            # 檢查 satellites 數據
            satellites = output_data.get('satellites', [])
            if not isinstance(satellites, list):
                errors.append("satellites 字段必須為列表")
                validation_score -= 0.3
            elif len(satellites) == 0:
                warnings.append("未載入任何衛星數據")
                validation_score -= 0.1
            else:
                # 檢查衛星數據格式
                sample_satellite = satellites[0]
                required_sat_fields = ['satellite_id', 'tle_line1', 'tle_line2', 'epoch_datetime']
                for field in required_sat_fields:
                    if field not in sample_satellite:
                        errors.append(f"衛星數據缺少必要字段: {field}")
                        validation_score -= 0.1

            # 檢查時間基準元數據 - Stage 1 核心職責
            metadata = output_data.get('metadata', {})
            time_fields = ['calculation_base_time', 'tle_epoch_time']
            for field in time_fields:
                if field not in metadata:
                    errors.append(f"缺少時間基準字段: {field}")
                    validation_score -= 0.15

            # 計算驗證等級
            if validation_score >= 0.95:
                grade = 'A+'
            elif validation_score >= 0.90:
                grade = 'A'
            elif validation_score >= 0.80:
                grade = 'B'
            elif validation_score >= 0.70:
                grade = 'C'
            else:
                grade = 'F'

            return {
                'valid': len(errors) == 0,
                'errors': errors,
                'warnings': warnings,
                'validation_score': validation_score,
                'data_quality_grade': grade,
                'stage1_compliance': len(errors) == 0
            }

        except Exception as e:
            self.logger.error(f"❌ 輸出驗證異常: {e}")
            return {
                'valid': False,
                'errors': [f"輸出驗證異常: {str(e)}"],
                'warnings': [],
                'validation_score': 0.0
            }

    def run_validation_checks(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """
        執行 Stage 1 專用驗證檢查

        Args:
            results: 處理結果數據

        Returns:
            驗證報告字典
        """
        try:
            self.logger.info("🔍 開始 Stage 1 驗證檢查...")

            validation_report = {
                'validation_timestamp': datetime.now(timezone.utc).isoformat(),
                'validation_status': 'unknown',
                'overall_status': 'UNKNOWN',
                'validation_details': {
                    'validator_used': 'Stage1RefactoredProcessor',
                    'validation_framework': 'Stage1_Specific_Checks',
                    'checks_performed': [],
                    'success_rate': 0.0
                }
            }

            # Stage 1 專用檢查項目
            checks = [
                ('tle_format_validation', self._validate_tle_format),
                ('tle_checksum_verification', self._validate_tle_checksums),
                ('data_completeness_check', self._validate_data_completeness),
                ('time_base_establishment', self._validate_time_base),
                ('satellite_data_structure', self._validate_satellite_structure)
            ]

            passed_checks = 0
            total_checks = len(checks)

            for check_name, check_function in checks:
                try:
                    check_result = check_function(results)
                    validation_report['validation_details'][check_name] = check_result
                    validation_report['validation_details']['checks_performed'].append(check_name)

                    if check_result.get('passed', False):
                        passed_checks += 1

                except Exception as e:
                    self.logger.error(f"❌ 檢查 {check_name} 失敗: {e}")
                    validation_report['validation_details'][check_name] = {
                        'passed': False,
                        'error': str(e)
                    }

            # 計算成功率和狀態
            success_rate = passed_checks / total_checks
            validation_report['validation_details']['success_rate'] = success_rate

            if success_rate >= 0.8:
                validation_report['validation_status'] = 'passed'
                validation_report['overall_status'] = 'PASS'
            elif success_rate >= 0.6:
                validation_report['validation_status'] = 'warning'
                validation_report['overall_status'] = 'WARNING'
            else:
                validation_report['validation_status'] = 'failed'
                validation_report['overall_status'] = 'FAIL'

            self.logger.info(f"✅ Stage 1 驗證完成: {validation_report['overall_status']} ({success_rate:.1%})")
            return validation_report

        except Exception as e:
            self.logger.error(f"❌ Stage 1 驗證系統異常: {e}")
            return {
                'validation_status': 'failed',
                'overall_status': 'FAIL',
                'validation_details': {
                    'error': str(e),
                    'validator_used': 'Stage1RefactoredProcessor',
                    'success_rate': 0.0
                }
            }

    def save_validation_snapshot(self, processing_results: Dict[str, Any]) -> bool:
        """
        保存驗證快照

        Args:
            processing_results: 處理結果

        Returns:
            bool: 快照保存是否成功
        """
        try:
            # 執行驗證檢查
            validation_results = self.run_validation_checks(processing_results)

            # 生成快照數據
            snapshot_data = {
                'stage': 1,
                'stage_name': 'refactored_tle_data_loading',
                'status': 'success' if validation_results['validation_status'] == 'passed' else 'failed',
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'processing_duration': processing_results.get('metadata', {}).get('processing_duration', 0),

                # 數據摘要
                'data_summary': {
                    'has_data': len(processing_results.get('satellites', [])) > 0,
                    'satellite_count': len(processing_results.get('satellites', [])),
                    'data_keys': list(processing_results.keys()),
                    'metadata_keys': list(processing_results.get('metadata', {}).keys())
                },

                # 驗證結果
                'validation_passed': validation_results['validation_status'] == 'passed',
                'validation_details': validation_results['validation_details'],
                'errors': [],
                'warnings': [],
                'next_stage_ready': validation_results['validation_status'] == 'passed',

                # 重構標記
                'refactored_version': True,
                'interface_compliance': True
            }

            # 保存快照文件
            snapshot_path = self.validation_dir / 'stage1_validation.json'
            with open(snapshot_path, 'w', encoding='utf-8') as f:
                json.dump(snapshot_data, f, indent=2, ensure_ascii=False, default=str)

            self.logger.info(f"💾 Stage 1 驗證快照已保存: {snapshot_path}")
            return True

        except Exception as e:
            self.logger.error(f"❌ 快照保存失敗: {e}")
            return False

    def _apply_refactored_post_processing(self, core_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        應用重構後的後處理

        Args:
            core_result: 核心處理器結果

        Returns:
            重構後的結果
        """
        # 深度複製避免修改原始數據
        import copy
        result = copy.deepcopy(core_result)

        # 增強時間基準元數據
        if 'metadata' in result:
            metadata = result['metadata']

            # 確保時間基準字段存在且格式正確
            self._enhance_time_base_metadata(metadata)

            # 添加重構版本標記
            metadata.update({
                'refactored_version': True,
                'interface_compliance': 'BaseStageProcessor_v2.0',
                'stage1_core_responsibilities': [
                    'tle_data_loading',
                    'data_integrity_validation',
                    'time_base_establishment',
                    'satellite_data_standardization'
                ]
            })

        # 增強衛星數據格式
        if 'satellites' in result:
            self._enhance_satellite_data_format(result['satellites'])

        return result

    def _enhance_time_base_metadata(self, metadata: Dict[str, Any]) -> None:
        """
        增強時間基準元數據

        Args:
            metadata: 元數據字典
        """
        # 確保時間格式標準化
        time_fields = ['calculation_base_time', 'tle_epoch_time', 'processing_start_time', 'processing_end_time']

        for field in time_fields:
            if field in metadata and metadata[field]:
                try:
                    # 確保時間格式為 ISO 8601
                    if isinstance(metadata[field], str):
                        # 解析並重新格式化以確保標準化
                        dt = datetime.fromisoformat(metadata[field].replace('Z', '+00:00'))
                        metadata[field] = dt.isoformat()
                except Exception as e:
                    self.logger.warning(f"⚠️ 時間字段 {field} 格式化失敗: {e}")

        # 添加時間基準元數據
        metadata['stage1_time_inheritance'] = {
            'time_base_established': 'calculation_base_time' in metadata,
            'tle_epoch_extracted': 'tle_epoch_time' in metadata,
            'time_precision_level': 'microsecond',
            'inheritance_ready_for_stage2': True
        }

    def _enhance_satellite_data_format(self, satellites: List[Dict[str, Any]]) -> None:
        """
        增強衛星數據格式

        Args:
            satellites: 衛星數據列表
        """
        for satellite in satellites:
            # 添加 Stage 1 處理標記
            satellite['stage1_processed'] = True
            satellite['data_loading_timestamp'] = datetime.now(timezone.utc).isoformat()

            # 驗證 TLE 格式並添加驗證標記
            if 'tle_line1' in satellite and 'tle_line2' in satellite:
                satellite['tle_format_validated'] = self._verify_tle_format(
                    satellite['tle_line1'],
                    satellite['tle_line2']
                )

    def _verify_tle_format(self, line1: str, line2: str) -> bool:
        """
        驗證 TLE 格式

        Args:
            line1: TLE 第一行
            line2: TLE 第二行

        Returns:
            bool: 格式是否正確
        """
        try:
            # 基本長度檢查
            if len(line1) != 69 or len(line2) != 69:
                return False

            # 行號檢查
            if line1[0] != '1' or line2[0] != '2':
                return False

            # NORAD ID 一致性檢查
            norad_id_1 = line1[2:7].strip()
            norad_id_2 = line2[2:7].strip()
            if norad_id_1 != norad_id_2:
                return False

            # Checksum 檢查
            if not self._verify_tle_checksum(line1) or not self._verify_tle_checksum(line2):
                return False

            return True

        except Exception:
            return False

    def _verify_tle_checksum(self, tle_line: str) -> bool:
        """
        驗證 TLE checksum (Modulo 10 算法)

        Args:
            tle_line: TLE 行

        Returns:
            bool: checksum 是否正確
        """
        try:
            if len(tle_line) != 69:
                return False

            # 計算 checksum
            checksum = 0
            for char in tle_line[:68]:
                if char.isdigit():
                    checksum += int(char)
                elif char == '-':
                    checksum += 1

            expected_checksum = checksum % 10
            actual_checksum = int(tle_line[68])

            return expected_checksum == actual_checksum

        except (ValueError, IndexError):
            return False

    # Stage 1 專用驗證方法
    def _validate_tle_format(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """驗證 TLE 格式"""
        satellites = results.get('satellites', [])
        if not satellites:
            return {'passed': False, 'error': '無衛星數據'}

        valid_count = 0
        total_count = min(len(satellites), 100)  # 檢查前100顆

        for satellite in satellites[:total_count]:
            if self._verify_tle_format(
                satellite.get('tle_line1', ''),
                satellite.get('tle_line2', '')
            ):
                valid_count += 1

        pass_rate = valid_count / total_count
        return {
            'passed': pass_rate >= 0.95,
            'pass_rate': pass_rate,
            'valid_satellites': valid_count,
            'total_checked': total_count
        }

    def _validate_tle_checksums(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """驗證 TLE checksums"""
        satellites = results.get('satellites', [])
        if not satellites:
            return {'passed': False, 'error': '無衛星數據'}

        valid_checksums = 0
        total_lines = 0

        for satellite in satellites[:100]:  # 檢查前100顆
            line1 = satellite.get('tle_line1', '')
            line2 = satellite.get('tle_line2', '')

            if line1 and self._verify_tle_checksum(line1):
                valid_checksums += 1
            if line2 and self._verify_tle_checksum(line2):
                valid_checksums += 1
            total_lines += 2

        pass_rate = valid_checksums / max(total_lines, 1)
        return {
            'passed': pass_rate >= 0.98,
            'pass_rate': pass_rate,
            'valid_checksums': valid_checksums,
            'total_lines': total_lines
        }

    def _validate_data_completeness(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """驗證數據完整性"""
        required_fields = ['stage', 'satellites', 'metadata']
        missing_fields = []

        for field in required_fields:
            if field not in results:
                missing_fields.append(field)

        return {
            'passed': len(missing_fields) == 0,
            'missing_fields': missing_fields,
            'completeness_score': (len(required_fields) - len(missing_fields)) / len(required_fields)
        }

    def _validate_time_base(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """驗證時間基準建立"""
        metadata = results.get('metadata', {})
        time_fields = ['calculation_base_time', 'tle_epoch_time']
        missing_time_fields = []

        for field in time_fields:
            if field not in metadata or not metadata[field]:
                missing_time_fields.append(field)

        return {
            'passed': len(missing_time_fields) == 0,
            'missing_time_fields': missing_time_fields,
            'time_base_established': len(missing_time_fields) == 0
        }

    def _validate_satellite_structure(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """驗證衛星數據結構"""
        satellites = results.get('satellites', [])
        if not satellites:
            return {'passed': False, 'error': '無衛星數據'}

        required_sat_fields = ['satellite_id', 'tle_line1', 'tle_line2', 'epoch_datetime']
        valid_satellites = 0

        for satellite in satellites[:10]:  # 檢查前10顆
            missing_fields = [field for field in required_sat_fields if field not in satellite]
            if len(missing_fields) == 0:
                valid_satellites += 1

        pass_rate = valid_satellites / min(len(satellites), 10)
        return {
            'passed': pass_rate >= 0.9,
            'pass_rate': pass_rate,
            'valid_satellites': valid_satellites
        }


# 工廠函數
def create_stage1_refactored_processor(config: Optional[Dict[str, Any]] = None) -> Stage1RefactoredProcessor:
    """
    創建重構後的 Stage 1 處理器實例

    Args:
        config: 配置參數

    Returns:
        Stage1RefactoredProcessor: 重構後的處理器實例
    """
    return Stage1RefactoredProcessor(config=config)


if __name__ == "__main__":
    # 測試重構後的處理器
    processor = create_stage1_refactored_processor({'sample_mode': True, 'sample_size': 10})
    result = processor.execute()
    print(f"重構處理結果: {result.status} - {len(result.data.get('satellites', []))} 顆衛星")